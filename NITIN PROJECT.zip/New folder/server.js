const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const app = express();
const port = 3000;

// Serve static files from the "public" directory
app.use(express.static('public'));

// Initialize SQLite database
const db = new sqlite3.Database(':memory:');

// Create a table and insert some sample data
db.serialize(() => {
    db.run("CREATE TABLE kpis (name TEXT, value INTEGER)");
    const stmt = db.prepare("INSERT INTO kpis VALUES (?, ?)");
    stmt.run("Revenue", 10000);
    stmt.run("Users", 500);
    stmt.finalize();
});

app.get('/kpi-data', (req, res) => {
    db.all("SELECT * FROM kpis", [], (err, rows) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.json(rows);
    });
});

// Serve the login page
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

// Serve the dashboard page
app.get('/dashboard', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'dashboard.html'));
});

// Serve the KPI page
app.get('/kpi', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'kpi.html'));
});

app.listen(port, () => {
    console.log('Server running at http://localhost:${port}/');
});