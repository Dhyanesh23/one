async function fetchKPIData() {
    try {
        const response = await fetch('/kpi-data');
        const data = await response.json();
        const container = document.getElementById('kpi-container');
        container.innerHTML = <pre>${JSON.stringify(data, null, 2)}</pre>;
    } catch (error) {
        console.error('Error fetching KPI data:', error);
    }
}

fetchKPIData();